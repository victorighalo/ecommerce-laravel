<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.hero', ['page' => $taxon_slug], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="ps-main">
        <div class="ps-container">
            <div class="ps-filter">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12 ">
                        <div class="ps-filter__trigger">
                            <div class="ps-filter__icon"><span></span></div>
                            <p>Filter Product</p>
                        </div>
                    </div>
                    
                        
                            
                        
                    
                </div>
                <div class="ps-filter__content">
                    <div class="ps-filter__column" data-mh="column">
                        <h3>SORT CATEGORIES BY</h3>
                        <ul class="ps-list--filter">
                            <li class="current"><a href="product-listing.html">All</a></li>
                            <li><a href="product-listing.html">Men</a></li>
                            <li><a href="product-listing.html">Women</a></li>
                            <li><a href="product-listing.html">Suite & Jean</a></li>
                            <li><a href="product-listing.html">Accessories</a></li>
                            <li><a href="product-listing.html">Kids</a></li>
                            <li><a href="product-listing.html">Handmade</a></li>
                        </ul>
                    </div>
                    <div class="ps-filter__column" data-mh="column">
                        <h3>SORT PRODUCTS BY</h3>
                        <ul class="ps-list--filter">
                            <li class="current"><a href="product-listing.html">Default Sorting</a></li>
                            <li><a href="product-listing.html">Sort by popularity</a></li>
                            <li><a href="product-listing.html">Sort by average rating</a></li>
                            <li><a href="product-listing.html">Sort by newness</a></li>
                            <li><a href="product-listing.html">Sort by price: low to high</a></li>
                            <li><a href="product-listing.html">Sort by price: high to low</a></li>
                        </ul>
                    </div>
                    <div class="ps-filter__column" data-mh="column">
                        <h3>FILTER BY PRICE</h3>
                        <ul class="ps-list--filter">
                            <li class="current"><a href="product-listing.html">All</a></li>
                            <li><a href="product-listing.html">£10.00 - £110.00</a></li>
                            <li><a href="product-listing.html">£110.00 - £210.00</a></li>
                            <li><a href="product-listing.html">£210.00 - £310.00</a></li>
                            <li><a href="product-listing.html">£310.00+</a></li>
                        </ul>
                    </div>
                    <div class="ps-filter__column" data-mh="column">
                        <h3>FILTER BY PRICE</h3>
                        <ul class="ps-list--color">
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                        </ul>
                    </div>
                    <div class="ps-filter__column" data-mh="column">
                        <h3>FILTER BY PRICE</h3>
                        <ul class="ps-list--filter">
                            <li class="current"><a href="product-listing.html">All</a></li>
                            <li><a href="product-listing.html">New</a></li>
                            <li><a href="product-listing.html">SaleOff</a></li>
                            <li><a href="product-listing.html">Show Only Products On Sale</a></li>
                            <li><a href="product-listing.html">In Stock Only</a></li>
                            <li><a href="product-listing.html">Out of stock</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 ">
                    <div class="ps-product">
                        <div class="ps-product__thumbnail">
                            <?php if($product->created_at->diff($now)->days < 5): ?>
                            <div class="ps-badge"><span>New</span></div>
                            <?php endif; ?>
                            
                                
                            
                                
                            <?php if($product->getMedia('images')->first()): ?>
                            <img src="<?php echo e(env('APP_URL').$product->getMedia('images')->first()->getUrl()); ?>" alt="">
                            <?php endif; ?>
                            <a class="ps-product__overlay" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>"></a>
                            <div class="ps-product__content full">
                                <div class="ps-product__variants">
                                    <?php if($product->getMedia('images')): ?>
                                    <?php $__currentLoopData = $product->getMedia('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item"><img src="<?php echo e(env('APP_URL').$image->getUrl()); ?>" alt=""></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                </div>
                                <select class="product-rating-home-view">
                                    <?php if( isset($product->averageRating) ): ?>
                                        <?php if( round($product->averageRating) > 0 ): ?>
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <?php if($i <= round($product->averageRating()) ): ?>
                                                    <option value="1"></option>
                                                <?php else: ?>
                                                    <option value="2"></option>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value=""></option>
                                        <option value="0"></option>
                                        <option value="2"></option>
                                        <option value="2"></option>
                                        <option value="2"></option>
                                        <option value="2"></option>
                                    <?php endif; ?>
                                </select><a class="ps-product__title" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>"><?php echo e($product->title()); ?></a>
                                <div class="ps-product__categories">
                                        <a href="<?php echo e(route('getCategoryContent', ['slug' => $product->taxons->first()->slug])); ?>">
                                        <?php echo e($product->taxons->first()->name); ?> - <?php echo e($product->taxons->first()->taxonomy->name); ?></a>
                                </div>
                                <p class="ps-product__price">
                                    &#8358;<?php echo e(number_format($product->price, '0', '.', ',')); ?>

                                </p>
                                <button class="ps-btn add_to_cart" data-slug="<?php echo e($product->slug); ?>">
                                    <i class="fa fa-circle-o-notch fa-spin processing off" aria-hidden="true"></i> Add To Cart
                                </button>
                                
                            </div>
                        </div>
                        <div class="ps-product__content">
                            <select class="product-rating-home-view">
                                <?php if( isset($product->averageRating) ): ?>
                                    <?php if( round($product->averageRating) > 0 ): ?>
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($product->averageRating()) ): ?>
                                                <option value="1"></option>
                                            <?php else: ?>
                                                <option value="2"></option>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <option value=""></option>
                                    <option value="0"></option>
                                    <option value="2"></option>
                                    <option value="2"></option>
                                    <option value="2"></option>
                                    <option value="2"></option>
                                <?php endif; ?>
                            </select><a class="ps-product__title" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>"><?php echo e($product->title()); ?></a>
                            <div class="ps-product__categories"><a href="<?php echo e(route('getCategoryContent', ['slug' => $product->taxons->first()->slug])); ?>"><?php echo e($product->taxons->first()->name); ?> - <?php echo e($product->taxons->first()->taxonomy->name); ?></a></div>
                            <p class="ps-product__price">
                                &#8358;<?php echo e(number_format($product->price, '0', '.', ',')); ?>

                            </p>
                        </div>
                    </div>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="ps-pagination">

            <ul class="pagination">
                <?php echo e($products->links('vendor.pagination.custom')); ?>

            </ul>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function () {

            $(".add_to_cart").click(function () {
                $(this).find(".processing").removeClass('off')
                $(this).prop('disabled', true)
                var slug = $(this).data('slug');
                var qty = 1;
                var self = this
                $.ajax({
                    url: "<?php echo e(route('add_to_cart')); ?>",
                    type: 'POST',
                    data: {qty: qty, slug: slug}
                })
                    .done(function (data) {
                        $(self).find(".processing").addClass('off')
                        $(self).find(".processing").prop('disabled', false)
                        $(".cart_count").html("<i>" + data.cart_count + "</i>")
                        Snackbar.show({
                            showAction: true,
                            text: 'Cart updated.',
                            actionTextColor: '#ffffff',
                            backgroundColor: "#53A6E8"
                        });

                    }).fail(function (error) {
                    $(self).find(".processing").addClass('off')
                    $(self).find(".processing").prop('disabled', false)
                    Snackbar.show({
                        showAction: true,
                        text: 'Cart update failed!.',
                        actionTextColor: '#ffffff',
                        backgroundColor: "#FE970D"
                    });
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>