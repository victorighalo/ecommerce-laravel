<form class="ps-form--search" action="<?php echo e(url('search')); ?>" method="get"><i class="furniture-search"></i>
    <input class="form-control" type="text" placeholder="Find product" name="product">
    <button>Search</button>
</form>