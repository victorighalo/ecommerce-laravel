<?php $__env->startSection('content'); ?>

    <div id="content">

        <!-- PAGES INNER -->
        <section class="chart-page login gray-bg padding-top-100 padding-bottom-100">
            <div class="container">

                <!-- Payments Steps -->
                <div class="shopping-cart">

                    <!-- SHOPPING INFORMATION -->
                    <div class="cart-ship-info">
                        <div class="row">

                            <!-- Login Register -->
                            <div class="col-sm-7 center-block">
                                <h3 class="text-center margin-40">Register</h3>

                                <!-- Login -->
                                <form method="POST" action="<?php echo e(route('register')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <ul class="row">
                                        <!-- Email -->
                                        <li class="col-md-12">
                                            <label> <?php echo e(__('Name')); ?>

                                                <input id="name" type="text"
                                                       class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                       name="name" value="<?php echo e(old('name')); ?>" required autofocus
                                                       class="form-control">
                                            </label>
                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                            <?php endif; ?>
                                        </li>
                                        <!-- Email -->
                                        <li class="col-md-12">
                                            <label> <?php echo e(__('E-Mail Address')); ?>

                                                <input id="email" type="email"
                                                       class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                       name="email" value="<?php echo e(old('email')); ?>" required autofocus
                                                       class="form-control">
                                            </label>
                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                            <?php endif; ?>
                                        </li>
                                        <!-- Password -->
                                        <li class="col-md-12">
                                            <label> Password
                                                <input id="password" type="password"
                                                       class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                       name="password" required class="form-control">
                                            </label>
                                            <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                            <?php endif; ?>
                                        </li>

                                        <!-- Password -->
                                        <li class="col-md-12">
                                            <label> Password
                                                <input id="password_confirmation" type="password"
                                                       class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>"
                                                       name="password_confirmation" required class="form-control">
                                            </label>
                                        </li>

                                        <!-- LOGIN -->
                                        <li class="col-md-6">
                                            <button type="submit" class="btn">REGISTER</button>
                                        </li>

                                        <!-- FORGET PASS -->
                                        <li class="col-md-6">
                                            <div class="margin-top-15 text-right">
                                                <?php if(Route::has('password.request')): ?>
                                                    <a  href="<?php echo e(route('password.request')); ?>">
                                                        <?php echo e(__('Forgot Your Password?')); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newmain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>