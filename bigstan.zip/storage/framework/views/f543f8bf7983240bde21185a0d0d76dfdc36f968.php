<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.image-modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row justify-content-center flex-grow mb-5 mt-5">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                                <div class="row justify-content-center">
                                    <div class="col-sm-8 p-4 mb-5">
                                        <h4 class="card-title font-weight-bold"> App Settings
                                        </h4>
                                        <div>
                                            <?php if(session('status')): ?>
                                                <div class="alert alert-success">
                                                    <?php echo e(session('status')); ?>

                                                </div>
                                            <?php endif; ?>
                                            <?php if(session('error')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e(session('error')); ?>

                                                </div>
                                            <?php endif; ?>
                                        <form id="product_form" action="<?php echo e(action('SettingController@update')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="row form-group">
                                                <div class="col-sm-12 mb-3">
                                                    <label for="store_name"><?php echo e(__('App name')); ?></label>
                                                    <input type="text" id="store_name" value="<?php echo e($app_settings->store_name); ?>" name="store_name" class="form-control" required>
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                </span>
                                                </div>

                                                <div class="col-sm-12 mb-3">
                                                    <label for="description"><?php echo e(__('Description')); ?></label>
                                                    <input type="text" id="description" value="<?php echo e($app_settings->store_description); ?>" name="store_description" class="form-control" name="description" required>
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                </span>
                                                </div>

                                                <div class="col-sm-12 mb-3">
                                                    <label for="store_address"><?php echo e(__('Address')); ?></label>
                                                    <input type="text" name="store_address" id="store_address" value="<?php echo e($app_settings->store_address); ?>" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-4 mb-3">
                                                    <label for="store_email"><?php echo e(__('Email')); ?></label>
                                                    <input type="text" name="store_email" id="store_email" value="<?php echo e($app_settings->store_email); ?>" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-4">
                                                    <label for="store_twitter"><?php echo e(__('Twitter')); ?></label>
                                                    <input type="url" name="store_twitter" value="<?php echo e($app_settings->store_twitter); ?>" id="store_twitter" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-4 mb-3">
                                                    <label for="store_facebook"><?php echo e(__('Facebook')); ?></label>
                                                    <input type="url" name="store_facebook" id="store_facebook" value="<?php echo e($app_settings->store_facebook); ?>" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-4">
                                                    <label for="store_instagram"><?php echo e(__('Instagram')); ?></label>
                                                    <input type="url" name="store_instagram" value="<?php echo e($app_settings->store_instagram); ?>" id="store_instagram" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-4 mb-3">
                                                    <label for="store_linkedin"><?php echo e(__('Linkedin')); ?></label>
                                                    <input type="url" name="store_linkedin" id="store_linkedin" value="<?php echo e($app_settings->store_linkedin); ?>" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-4 mb-3">
                                                    <label for="store_youtube"><?php echo e(__('YouTube')); ?></label>
                                                    <input type="url" name="store_youtube" id="store_youtube" value="<?php echo e($app_settings->store_youtube); ?>" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                                <div class="col-sm-6">
                                                    <label for="phone"><?php echo e(__('Phone')); ?></label>
                                                    <input type="phone" value="<?php echo e($app_settings->store_phone); ?>" name="store_phone" id="phone" class="form-control">
                                                    <span class="invalid-feedback errorshow" role="alert">
                                                    </span>
                                                </div>

                                            </div>


                                            <div class="row justify-content-center form-group">
                                                <div class="col-sm-12">
                                                    <label for="about"><?php echo e(__('About')); ?></label>
                                                    <textarea class="form-control" name="about" id="about" cols="30" rows="5"><?php echo e($app_settings->store_about); ?></textarea>
                                                    <span class="invalid-feedback errorshow" role="alert">
                                        </span>
                                                </div>


                                            </div>
                                            <div class="mt-1">
                                                <button class="btn float-right btn-primary btn-lg font-weight-medium add_product_btn" type="submit">
                                                    <i class="fas fa-spinner fa-spin off process_indicator"></i>
                                                    <span><?php echo e(__('Save')); ?></span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('plugins/bootstrap-tagsinput.min.js')); ?>"></script>
    <script>

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>