<?php $__env->startSection('content'); ?>

    <!--======= SUB BANNER =========-->
    <?php echo $__env->make('partials.frontend.sub_banner', ['title' => 'Search'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="content">

        <!-- Products -->
        <section class="shop-page padding-top-100 padding-bottom-100">
            <div class="container">
                <div class="row">

                    <!-- Item Content -->
                    <div class="col-md-9">
                        <!-- Item -->
                        <div id="products" class="arrival-block col-item-3 list-group">
                            <?php if(count($products)): ?>
                                <div class="row">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Item -->
                                        <div class="item">
                                            <div class="img-ser">
                                                <!-- Sale -->

                                            <!-- Images -->
                                                <div class="thumb">
                                                    <?php if($product->hasPhoto()): ?>
                                                        <img class="img-1" src="<?php echo e($product->FirstImage); ?>" alt="<?php echo e($product->title()); ?>">
                                                        <img class="img-2" src="<?php echo e($product->FirstImage); ?>" alt="<?php echo e($product->title()); ?>">
                                                <?php endif; ?>
                                                <!-- Overlay  -->

                                                </div>

                                                <!-- Item Name -->
                                                <div class="item-name fr-grd">
                                                    <a class="i-tittle" href="<?php echo e(route('getProductDetails', [
                                            'taxon_slug' => $product->taxons->first()->slug,
                                            'product_slug' => $product->slug
                                            ])); ?>"><?php echo e($product->title()); ?></a>
                                                    <span class="price"><small>&#8358;</small> <?php echo e(number_format($product->price, '0', '.', ',')); ?></span> <a class="deta animated fadeInRight"  href="<?php echo e(route('getProductDetails', [
                                            'taxon_slug' => $product->taxons->first()->slug,
                                            'product_slug' => $product->slug
                                            ])); ?>">View Detail</a> </div>
                                                <!-- Item Details -->
                                                <div class="cap-text">
                                                    <div class="item-name">   <a class="i-tittle" href="<?php echo e(route('getProductDetails', [
                                            'taxon_slug' => $product->taxons->first()->slug,
                                            'product_slug' => $product->slug
                                            ])); ?>"><?php echo e($product->title()); ?></a> <span class="price"><small>&#8358;</small> <?php echo e(number_format($product->price, '0', '.', ',')); ?></span>

                                                        <p><?php echo e($product->excerpt); ?></p>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <div class="container">
                                        <div class="alert-icon">
                                            <i class="fa fa-exclamation-circle"></i>
                                        </div>
                                        <h5>Products unavailable for category</h5>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>


                        <!-- Pagination -->
                        <?php echo e($products->links('vendor.pagination.custom')); ?>


                    </div>

                    <!-- Shop SideBar -->
                    <div class="col-md-3">
                        <div class="shop-sidebar">

                            <!-- Category -->
                            <h5 class="shop-tittle margin-bottom-30">categories</h5>
                            <ul class="shop-cate">
                                <?php if($categories): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('get_category_content', ['taxon_slug' => $category->slug])); ?>" > <?php echo e($category->name); ?> <span><?php echo e(count($category->products)); ?></span></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        <?php echo $__env->make('partials.frontend.product_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newmain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>