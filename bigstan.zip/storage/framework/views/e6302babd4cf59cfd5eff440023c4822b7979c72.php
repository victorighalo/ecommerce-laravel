<div class="ps-hero bg--cover" data-background="<?php echo e(asset('images/hero/bread-1.jpg')); ?>">
    <div class="ps-container">
        <h3><?php echo e($page); ?></h3>
        <div class="ps-breadcrumb">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="active"><?php echo e($page); ?></li>
            </ol>
        </div>
    </div>
</div>
