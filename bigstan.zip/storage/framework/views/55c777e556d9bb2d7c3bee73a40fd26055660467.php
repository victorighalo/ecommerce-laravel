<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.hero', ['page' => $product->title()], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="ps-main">
        <div class="ps-container">
            <div class="ps-product--detail">
                <div class="row">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12 ">
                        <div class="ps-product__thumbnail">
                            <div class="ps-product__image">
                                <?php if($product->getMedia('images')): ?>
                                    <?php $__currentLoopData = $product->getMedia('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <div class="item">
                                            <a href="<?php echo e(env('APP_URL').$image->getUrl()); ?>">
                                            <img src="<?php echo e(env('APP_URL').$image->getUrl()); ?>" alt="<?php echo e($product->title()); ?>">
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="ps-product__preview">
                                <div class="ps-product__variants">
                                    <?php if($product->getMedia('images')): ?>
                                        <?php $__currentLoopData = $product->getMedia('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">
                                                    <img src="<?php echo e(env('APP_URL').$image->getUrl()); ?>" alt="<?php echo e($product->title()); ?>">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                
                                    
                                        
                                    
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12 ">
                        <div class="ps-product__info">
                            <div class="ps-product__rating">
                                <select class="product-rating-view">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($ratings) ): ?>
                                            <option value="1"></option>
                                        <?php else: ?>
                                            <option value="2"></option>
                                        <?php endif; ?>
                                        <?php endfor; ?>
                                </select><a href="#tab_02" aria-controls="tab_02" role="tab" data-toggle="tab">(Read all <?php echo e($product->commentCount()); ?> reviews)</a>
                            </div>
                            <h1><?php echo e($product->title()); ?></h1>
                            <p class="ps-product__category">
                                <?php if(isset($tags)): ?>
                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="#"><span class="badge badge-primary"><?php echo e($tag); ?></span></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                            </p>
                            <h3 class="ps-product__price"> <span>&#8358;</span> <?php echo e(number_format($product->price, '0', '.', ',')); ?></h3>
                            <div class="ps-product__short-desc">
                                <p><?php echo e($product->meta_description); ?></p>
                            </div>
                            <div class="ps-product__block ps-product__size">
                                <h4>CHOOSE QUANTITY</h4>
                                <div class="form-group ps-number" style="float: left;">
                                    <input class="form-control" name="item_qty" type="text" value="1"><span class="up"></span><span class="down"></span>
                                </div>
                            </div>
                            <div class="ps-product__shopping">
                                <button class="ps-btn" data-slug="<?php echo e($product->slug); ?>" id="add_to_cart">
                                    <i class="fa fa-circle-o-notch fa-spin processing off" aria-hidden="true"></i> Add To Cart
                                </button>
                            </div>
                            <div class="ps-product__sharing">
                                <p>Share this:<a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-dribbble"></i></a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ps-product__content">
                    <ul class="tab-list" role="tablist">
                        <li class="active"><a href="#tab_01" aria-controls="tab_01" role="tab" data-toggle="tab">Overview</a></li>
                        <li><a href="#tab_02" aria-controls="tab_02" role="tab" data-toggle="tab">Review</a></li>
                    </ul>
                </div>
                <div class="tab-content">
                    <div class="tab-pane active" role="tabpanel" id="tab_01">
                        <?php echo $product->description; ?>

                          </div>
                    <div class="tab-pane" role="tabpanel" id="tab_02">
                        <?php if(isset($product->comments)): ?>
                        <?php if(count($product->comments)): ?>
                        <p><?php echo e($product->commentCount()); ?> reviews for <strong><?php echo e($product->title()); ?></strong></p>
                        <?php if(isset($product)): ?>
                        <?php if(isset($product->comments)): ?>
                        <?php if(count($product->comments)): ?>
                            <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ps-review">
                            <div class="ps-review__thumbnail"><img src="images/user/1.jpg" alt=""></div>
                            <div class="ps-review__content">

                                <header>
                                    
                                        
                                        
                                        
                                        
                                        
                                    
                                    <p>By<a href="">
                                            <?php if(Auth::guest()): ?>
                                                <?php echo e(ucwords($comment->creator->firstname)); ?>

                                                <?php else: ?>
                                            <?php echo e(Auth::user()->firstname); ?>

                                                <?php endif; ?>
                                        </a> - <?php echo e($comment->created_at->diffForHumans()); ?></p>
                                </header>
                                <p><?php echo e($comment->body); ?></p>
                            </div>
                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                            <?php else: ?>
                            <p>Be the first to add a review for this product</p>
                            <?php endif; ?>
                            <?php else: ?>
                                <p>Be the first to add a review for this product</p>
                        <?php endif; ?>
                        <form class="ps-form--product-review" action="<?php echo e(route('add_comment', ['product_id' => $product->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <h4>ADD YOUR REVIEW</h4>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
                                    <div class="form-group">
                                        <strong><label>
                                            <?php if(Auth::guest()): ?>
                                                Guest
                                            <?php else: ?>
                                                <?php echo e(Auth::user()->firstname); ?>

                                            <?php endif; ?>
                                        </label>
                                        </strong>
                                    </div>
                                    <div class="form-group">
                                        <label>Title:<sup>*</sup></label>
                                        <input class="form-control" type="text" placeholder="" name="title" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Your rating</label>
                                        <span class="rating_indicator off">
                                            <i class="fa fa-circle-o-notch fa-spin processing" aria-hidden="true"></i>
                                            <span> Rating...</span>
                                        </span>
                                        <select class="product-rating-comment" data-slug="<?php echo e($product->slug); ?>">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>

                                             </div>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12 ">
                                    <div class="form-group">
                                        <label>Your Review:<sup>*</sup></label>
                                        <textarea class="form-control" rows="6" name="comment" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button class="ps-btn">Submit Review</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>

        $(document).ready(function () {

            $("#add_to_cart").click(function () {
                $(".processing").removeClass('off')
                $("#add_to_cart").prop('disabled', true)
                var slug = $(this).data('slug');
                var qty = $("input[name='item_qty']").val();
                if(qty < 1){
                    alert('Qty less than 1')
                    return false;
                }
                $.ajax({
                    url: "<?php echo e(route('add_to_cart')); ?>",
                    type: 'POST',
                    data: {qty: qty, slug:slug}
                })
                    .done(function (data) {
                        $(".processing").addClass('off')
                        $("#add_to_cart").prop('disabled', false)
                        $(".cart_count").html("<i>"+data.cart_count+"</i>")
                        Snackbar.show({
                            showAction: true,
                            text: 'Cart updated.',
                            actionTextColor: '#ffffff',
                            backgroundColor:"#53A6E8"
                        });

                    }).fail(function (error) {
                    $(".processing").addClass('off')
                    $("#add_to_cart").prop('disabled', false)
                    Snackbar.show({
                        showAction: true,
                        text: 'Cart update failed!.',
                        actionTextColor: '#ffffff',
                        backgroundColor:"#FE970D"
                    });
                });
            });

            $('select.product-rating-comment').barrating({
                theme: 'fontawesome-stars',
                onSelect: function(value, text, event) {
                    if (typeof(event) !== 'undefined') {
                        // rating was selected by a user
                        $(".rating_indicator").removeClass('off')
                        var rating = $(event.target).data('rating-value');
                        var slug = $(event.target).parent().prev().data('slug');

                        $.ajax({
                            url: "<?php echo e(route('rate_product')); ?>",
                            type: 'POST',
                            data: {rating: rating, slug: slug}
                        })
                            .done(function (data) {
                                $(".rating_indicator").addClass('off')
                                Snackbar.show({
                                    showAction: true,
                                    text: 'Product rated.',
                                    actionTextColor: '#ffffff',
                                    backgroundColor: "#53A6E8"
                                });

                            }).fail(function (error) {
                            $(".rating_indicator").addClass('off')
                            Snackbar.show({
                                showAction: true,
                                text: 'Product rating failed!.',
                                actionTextColor: '#ffffff',
                                backgroundColor: "#FE970D"
                            });
                        })
                    }else {
                        // rating was selected programmatically
                        // by calling `set` method
                    }
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>