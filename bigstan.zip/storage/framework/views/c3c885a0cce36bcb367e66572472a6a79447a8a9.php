<div class="top-bar">
    <div class="container-full">
        <p><i class="icon-map-pin"></i> <?php echo e($app_settings->store_address ? $app_settings->store_address : ""); ?> </p>
        <p class="call"> <i class="icon-call-in"></i> <?php echo e($app_settings->store_phone ? $app_settings->store_phone : ""); ?> </p>

        <!-- Login Info -->
        <div class="login-info">
            <ul>
                <li><a href="<?php echo e(url('cart')); ?>">MY CART</a></li>      <!-- USER BASKET -->
                <li class="dropdown user-basket"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <?php echo e(Cart::itemCount()); ?> Items <i class="icon-basket-loaded"></i> </a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = Cart::getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="media-left">
                                <div class="cart-img"> <a href="#"> <img class="media-object img-responsive" src="<?php echo e($item->product->FirstImage); ?>" alt="<?php echo e($item->product->name); ?>"> </a> </div>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading"><?php echo e($item->product->name); ?></h6>
                                <span class="price"><small>&#8358;</small> <?php echo e(number_format($item->price, '0', '.', ',')); ?></span> <span class="qty">QTY: <?php echo e($item->quantity); ?></span> </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="margin-0">
                            <div class="row">
                                <div class="col-sm-6"> <a href="<?php echo e(url('cart')); ?>" class="btn">VIEW CART</a></div>
                                <div class="col-sm-6 "> <a href="<?php echo e(url('checkout')); ?>" class="btn">CHECK OUT</a></div>
                            </div>
                        </li>
                    </ul>
                </li>

                <?php if(auth()->guard()->guest()): ?>
                <li><a href="<?php echo e(url('login')); ?>">LOGIN</a></li>
                <li><a href="<?php echo e(url('register')); ?>">REGISTER</a></li>
                <?php else: ?>
                    <li><a href="#."> MY ACCOUNT </a></li>
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('LOGOUT')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<header class="sticky">
    <div class="container">

        <!-- Logo -->
        <div class="logo"> <a href="index.html"><img class="img-responsive" src="images/logo.svg" alt="" ></a> </div>
        <nav class="navbar ownmenu navbar-expand-lg">
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"> <span></span> </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="nav">
                    <li> <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li> <a href="<?php echo e(url('about')); ?>">About </a> </li>
                    <li> <a href="<?php echo e(url('contact')); ?>"> contact</a> </li>
                </ul>
            </div>

            <!-- Nav Right -->
            <div class="nav-right">
                <ul class="navbar-right">
                    <!-- USER INFO -->
                    <li> <a href="#"><i class="lnr lnr-user"></i> </a></li>
                    <!-- USER BASKET -->
                    <li> <a href="<?php echo e(url('cart')); ?>"><span class="c-no"><?php echo e(Cart::itemCount()); ?></span><i class="lnr lnr-cart"></i> </a> </li>
                    <!-- SEARCH BAR -->
                    <li> <a href="javascript:void(0);" class="search-open"><i class="lnr lnr-magnifier"></i></a>
                        <div class="search-inside animated bounceInUp"> <i class="icon-close search-close"></i>
                            <div class="search-overlay"></div>
                            <div class="position-center-center">
                                <div class="search">
                                    <form action="<?php echo e(url('search')); ?>" method="get">
                                        <input type="search" placeholder="Search Shop" name="product">
                                        <button type="submit"><i class="icon-check"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <div class="clearfix"></div>
</header>