<?php $__env->startSection('content'); ?>

    <div id="content">

        <!-- PAGES INNER -->
        <section class="chart-page login gray-bg padding-top-100 padding-bottom-100">
            <div class="container">

                <!-- Payments Steps -->
                <div class="shopping-cart">

                    <!-- SHOPPING INFORMATION -->
                    <div class="cart-ship-info">
                        <div class="row">

                            <!-- Login Register -->
                            <div class="col-sm-7 center-block">
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <h3 class="text-center margin-40"><?php echo e(__('Reset Password')); ?></h3>

                                <!-- Login -->
                                <form method="POST" action="<?php echo e(route('password.email')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <ul class="row">
                                        <!-- Email -->
                                        <li class="col-md-12">
                                            <label> <?php echo e(__('E-Mail Address')); ?>

                                                <input id="email" type="email"
                                                       class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                       name="email" value="<?php echo e(old('email')); ?>" required autofocus
                                                       class="form-control">
                                            </label>
                                            <?php if($errors->has('email')): ?>
                                                <span role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                            <?php endif; ?>
                                        </li>

                                        <!-- LOGIN -->
                                        <li class="col-md-6">
                                            <button type="submit" class="btn">  <?php echo e(__('Send Password Reset Link')); ?></button>
                                        </li>


                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newmain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>