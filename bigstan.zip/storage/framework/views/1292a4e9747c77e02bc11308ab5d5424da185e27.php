<?php $__env->startSection('content'); ?>

    <!--======= SUB BANNER =========-->
    <?php echo $__env->make('partials.frontend.sub_banner', ['title' => 'About us'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content -->
    <div id="content">

        <!-- History -->
        <section class="history-block padding-top-100 padding-bottom-100">
            <div class="container">
                <div class="about-us-con">
                    <?php echo e($app_settings->store_about ? $app_settings->store_about : ""); ?>

                </div>
            </div>
        </section>



        
        <?php echo $__env->make('partials.frontend.product_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newmain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>