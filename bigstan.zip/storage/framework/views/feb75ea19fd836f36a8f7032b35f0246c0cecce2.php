<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.frontend.slider_home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="content">
        <!-- Shop By Category -->
        <?php echo $__env->make('partials.frontend.home._categories', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Products by Category -->
        <?php echo $__env->make('partials.frontend.home._products_by_category', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Popular Products -->
        <?php echo $__env->make('partials.frontend.home._newproducts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('partials.frontend.product_request', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newmain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>