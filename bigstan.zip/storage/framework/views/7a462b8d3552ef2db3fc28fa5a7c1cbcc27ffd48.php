<div class="ps-section ps-home-best-product">
    <div class="ps-container">
        <div class="ps-section__header text-center">
            <h3 class="ps-section__title">LATEST PRODUCTS</h3><span class="ps-section__line"></span>
        </div>
        <div class="ps-section__content mt-100">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 ">
                    <div class="ps-product">
                        <div class="ps-product__thumbnail">
                            <div class="ps-badge"><span>New</span></div>
                            
                            <?php if($product->getMedia('images')): ?>
                            <img src="<?php echo e(env('APP_URL').$product->getMedia('images')->first()->getUrl()); ?>" alt="<?php echo e($product->title()); ?>">
                            <?php endif; ?>
                            <a class="ps-product__overlay" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>">

                            </a>
                            <div class="ps-product__content full">
                                <div class="ps-product__variants">
                                    <?php if($product->getMedia('images')): ?>
                                        <?php $__currentLoopData = $product->getMedia('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">
                                                <a href="<?php echo e($image->getFullUrl()); ?>">
                                                    <img src="<?php echo e(env('APP_URL').$image->getUrl()); ?>" alt="<?php echo e($product->title()); ?>">
                                                </a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <select class="product-rating-home-view">
                                    <?php if( isset($product->averageRating) ): ?>
                                    <?php if( round($product->averageRating) > 0 ): ?>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <?php if($i <= round($product->averageRating()) ): ?>
                                            <option value="1"></option>
                                        <?php else: ?>
                                            <option value="2"></option>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value=""></option>
                                        <option value="0"></option>
                                        <option value="2"></option>
                                        <option value="2"></option>
                                        <option value="2"></option>
                                        <option value="2"></option>
                                        <?php endif; ?>
                                </select>
                                <a class="ps-product__title" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>"><?php echo e($product->title()); ?></a>
                                <div class="ps-product__categories">
                                    <a href="<?php echo e(route('getCategoryContent', ['slug' => $product->taxons->first()->slug])); ?>"><?php echo e($product->taxons->first()->name); ?> - <?php echo e($product->taxons->first()->taxonomy->name); ?></a></div>
                                <p class="ps-product__price">
                                    &#8358;<?php echo e(number_format($product->price, '0', '.', ',')); ?>

                                </p>
                                <button class="ps-btn add_to_cart" data-slug="<?php echo e($product->slug); ?>">
                                    <i class="fa fa-circle-o-notch fa-spin processing off" aria-hidden="true"></i> Add To Cart
                                </button>
                                
                            </div>
                        </div>
                        <div class="ps-product__content">
                            <select class="product-rating-home-view">
                                <?php if( isset($product->averageRating) ): ?>
                                    <?php if( round($product->averageRating) > 0 ): ?>
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($product->averageRating()) ): ?>
                                                <option value="1"></option>
                                            <?php else: ?>
                                                <option value="2"></option>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <option value=""></option>
                                    <option value="0"></option>
                                    <option value="2"></option>
                                    <option value="2"></option>
                                    <option value="2"></option>
                                    <option value="2"></option>
                                <?php endif; ?>
                            </select>
                            <a class="ps-product__title" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>"><?php echo e($product->title()); ?></a>
                            <div class="ps-product__categories"><a href="<?php echo e(route('getCategoryContent', ['slug' => $product->taxons->first()->slug])); ?>"><?php echo e($product->taxons->first()->name); ?> - <?php echo e($product->taxons->first()->taxonomy->name); ?></a></div>
                            <p class="ps-product__price">
                                <?php echo e($product->delivery_price['amount']); ?>

                                &#8358;<?php echo e(number_format($product->price, '0', '.', ',')); ?>

                            </p>
                        </div>
                    </div>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function () {

            $(".add_to_cart").click(function () {
                $(this).find(".processing").removeClass('off')
                $(this).prop('disabled', true)
                var slug = $(this).data('slug');
                var qty = 1
                var self = this;
                $.ajax({
                    url: "<?php echo e(route('add_to_cart')); ?>",
                    type: 'POST',
                    data: {qty: qty, slug: slug}
                })
                    .done(function (data) {
                        $(self).find(".processing").addClass('off')
                        $(self).find(".processing").prop('disabled', false)
                        $(".cart_count").html("<i>" + data.cart_count + "</i>")
                        Snackbar.show({
                            showAction: true,
                            text: 'Cart updated.',
                            actionTextColor: '#ffffff',
                            backgroundColor: "#53A6E8"
                        });

                    }).fail(function (error) {
                    $(self).find(".processing").addClass('off')
                    $(self).find(".processing").prop('disabled', false)
                    Snackbar.show({
                        showAction: true,
                        text: 'Cart update failed!.',
                        actionTextColor: '#ffffff',
                        backgroundColor: "#FE970D"
                    });
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>