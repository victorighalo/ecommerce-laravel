<section class="sub-bnr" data-stellar-background-ratio="0.5">
    <div class="position-center-center">
        <div class="container">
            <h4><?php echo e($title ? $title : ''); ?></h4>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="active"><?php echo e($title ? $title : ''); ?></li>
            </ol>
        </div>
    </div>
</section>