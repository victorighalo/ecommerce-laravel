<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name')); ?></title>
    <!-- Styles -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <link href="<?php echo e(asset('admin/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/bootstrap-tagsinput.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/quill.snow.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/quill.bubble.css')); ?>" rel="stylesheet">
    <style>
        .bootstrap-tagsinput{
            width: 100%;
        }
        .bootstrap-tagsinput .tag {
            color: black;
            background: silver;
            padding: 3px;
        }
        .product_img_container{
            display: inline-block;
            position: relative;
        }
        .product_img_container:hover .product_img_container_delete{
            display: block;
            width: 100%;
            height: 100%;
            top: 0;
            left:0;
            background: rgba(000,000,000,0.7);
            cursor: pointer;
        }
        .product_img_container_delete{
            position: absolute;
            padding: 10px;
        }
    </style>
</head>
<body>
<div id="app">
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
    <?php echo $__env->make('partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- partial -->
        <div class="page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <?php echo $__env->make('partials.footer_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</body>
<!-- Scripts -->
<script src="<?php echo e(asset('admin/js/manifest.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/vendor.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/app.js')); ?>" ></script>
<script src="<?php echo e(asset('admin/js/all.js')); ?>" ></script>
<script src="<?php echo e(asset('admin/js/quill.min.js')); ?>" ></script>
<script src="<?php echo e(asset('plugins/jquery.blockUI.js')); ?>" ></script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<?php echo $__env->yieldPushContent('script'); ?>
</html>
