<div class="ps-section ps-home-best-product">
    <div class="ps-container">
        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->products->count() > 0): ?>
            <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <a href="<?php echo e(route('getCategoryContent', ['taxon_slug' => $category->slug])); ?>"><?php echo e($category->name); ?> - <?php echo e($category->taxonomy->name); ?></a>
                </h3>
            </div>
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->getMedia('images')->first()): ?>
                            <div class="col-sm-2 products_by_category">
                                <a class="ps-product__overlay" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $item->taxons->first()->slug,
                            'product_slug' => $item->slug
                            ])); ?>">
                                <img
                                        src="<?php echo e(env('APP_URL').$item->getMedia('images')->first()->getUrl()); ?>"
                                        alt="<?php echo e($item->title()); ?>"
                                        class="img-responsive"
                                >
                                </a>
                                    <div class="product_title">
                                        <a class="ps-product__overlay" href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $item->taxons->first()->slug,
                            'product_slug' => $item->slug
                            ])); ?>">
                                <?php echo e(str_limit(strtoupper($item->title()),20, '...')); ?>

                                        </a>
                                    </div>

                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>