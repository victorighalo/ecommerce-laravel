
<header class="header" data-sticky="true">
    <div class="header__top">
        <div class="ps-container">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-6 col-xs-12 ">

                </div>
                <div class="col-lg-6 col-md-4 col-sm-6 col-xs-12 ">
                    <div class="header__actions"><a href="#">Login & Regiser</a>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <nav class="navigation">
        <div class="ps-container"><a class="ps-logo" href="<?php echo e(url('/')); ?>"><img src="images/logo.png" alt=""></a>
            <ul class="main-menu menu">
                <li class="current-menu-item"><a href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="menu-item-has-children"><a href="#">Categories</a>
                    <ul class="sub-menu">
                        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->products->count() > 0): ?>
                        <li class="menu-item-has-children">

                            <a href="<?php echo e(route('getCategoryContent', ['taxon_slug' => $category->slug])); ?>"><?php echo e($category->name); ?> - <?php echo e($category->taxonomy->name); ?></a>
                        </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            
                                
                                
                                
                                
                                
                            
                        
                    </ul>
                </li>
                <li><a href="<?php echo e(url('about')); ?>">About</a></li>
                <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
            </ul>
            <div class="menu-toggle"><span></span></div>
            <div class="ps-cart"><a class="ps-cart__toggle" href="<?php echo e(url('cart')); ?>"><span class="cart_count">
                        <?php if(isset($cart_count)): ?>
                        <i><?php echo e($cart_count); ?></i>
                            <?php else: ?>
                            0
                            <?php endif; ?>
                    </span><img src="images/market.svg" alt=""></a>
                
                    
                        
                            
                            
                                
                            
                        
                        
                            
                            
                                
                            
                        
                        
                            
                            
                                
                            
                        
                    
                    
                        
                        
                    
                    
                
            </div>
      <?php echo $__env->make('partials._search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </nav>
</header>
