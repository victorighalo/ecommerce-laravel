<section class="light-gray-bg padding-top-100 padding-bottom-100">
    <div class="container">

        <!-- Main Heading -->
        <div class="heading text-center">
            <h4>Newly Added Products</h4>
            <hr>
        </div>

        <!-- Popular Item Slide -->
        <?php if($latest_products): ?>
        <?php if(count($latest_products) > 0): ?>
        <div class="papular-block block-slide-con">
        <?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Item -->
            <div class="item">
                
                <div class="on-sale"> New </div>
                <!-- Item img -->
                <div class="item-img">
                    <?php if($product->hasPhoto()): ?>
                        <img class="img-1" src="<?php echo e($product->FirstImage); ?>" alt="<?php echo e($product->title()); ?>">
                        <img class="img-2" src="<?php echo e($product->FirstImage); ?>" alt="<?php echo e($product->title()); ?>">
                    <?php endif; ?>

                </div>

                <!-- Item Name -->
                <div class="item-name">
                    <a href="<?php echo e(route('getProductDetails', [
                            'taxon_slug' => $product->taxons->first()->slug,
                            'product_slug' => $product->slug
                            ])); ?>"><?php echo e($product->title()); ?> </a>
                    <p><?php echo e($product->excerpt); ?></p>
                </div>
                <!-- Price -->
                <span class="price"><small>&#8358;</small> <?php echo e(number_format($product->price, '0', '.', ',')); ?></span> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <?php endif; ?>
            <?php endif; ?>
    </div>
</section>
