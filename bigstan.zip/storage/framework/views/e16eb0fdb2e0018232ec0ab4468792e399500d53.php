<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link href="apple-touch-icon.png" rel="apple-touch-icon">
    <link href="favicon.png" rel="icon">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/furniture-icon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/owl-carousel/assets/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/jquery-bar-rating/dist/themes/fontawesome-stars.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/slick/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/lightGallery-master/dist/css/lightgallery.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/snackbar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <style>

        .off {
            display: none;
        }
        .on {
            display: block;
        }
        .products_by_category .product_title{
            background: #fff;
            padding: 15px 10px;
            font-weight: bold;
            font-size: 14px;
        }
        .products_by_category .product_title a{
            font-weight: bold;
            font-size: 13px;
        }
        .products_by_category img{
            max-height: 200px;
            min-height: 200px;
            min-width: 100%;
            width: 100%;
            height: auto;
        }
    </style>
</head>



<body>
<div id="app">
    <div class="header--sidebar"></div>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<script src="<?php echo e(asset('plugins/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/lightGallery-master/dist/js/lightgallery-all.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-bar-rating/dist/jquery.barrating.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/imagesloaded.pkgd.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/masonry.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/slick/slick/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery.matchHeight-min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/elevatezoom/jquery.elevatezoom.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/snackbar.min.js')); ?>"></script>

<!-- Custom scripts-->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
