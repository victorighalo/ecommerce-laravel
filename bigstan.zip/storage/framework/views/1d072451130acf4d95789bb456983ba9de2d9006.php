<section class="padding-top-100 padding-bottom-100">
    <div class="container-full">

        <!-- Main Heading -->
        <div class="heading text-center">
            <h4>Top categories</h4>
            
        </div>

        <!-- New Arrival -->
        <div class="arrival-block">
            <ul class="nav nav-tabs" role="tablist">
                <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->products->count() > 0): ?>
                        <?php if($i == 0): ?>
                        <li class="nav-item"> <a class="active"  data-toggle="tab" href="#<?php echo e($category->taxonomy->name); ?>" role="tab" aria-selected="true"><?php echo e($category->name); ?> - <?php echo e($category->taxonomy->name); ?></a> </li>
                        <?php else: ?>
                         <li class="nav-item"> <a class=""  data-toggle="tab" href="#<?php echo e($category->taxonomy->name); ?>" role="tab" aria-selected="true"><?php echo e($category->name); ?> - <?php echo e($category->taxonomy->name); ?></a> </li>
                        <?php endif; ?>
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="arrival-tab">
            <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->products->count() > 0): ?>
                    <?php if($index == 0): ?>
                        <div class="tab-pane fade show active" id="<?php echo e($category->taxonomy->name); ?>" role="tabpanel">

                        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->hasPhoto()): ?>
                            <!-- Item -->
                            <div class="item">
                                <div class="img-ser">
                                    <img
                                            class="img-1 lazyload"
                                            src="<?php echo e($item->FirstImage); ?>"
                                            alt="<?php echo e($item->title()); ?>"
                                    >
                                    <img class="img-2 lazyload" src="<?php echo e($item->FirstImage); ?>" alt="">

                                </div>
                                <!-- Item Name -->
                                <div class="item-name">
                                    <a  class="i-tittle"
                                        href="<?php echo e(route('getProductDetails', [
                                                    'taxon_slug' => $item->taxons->first()->slug,
                                                    'product_slug' => $item->slug
                                                    ])); ?>">
                                        <?php echo e(str_limit(strtoupper($item->title()),20, '...')); ?>

                                    </a>
                                    <span class="price"><small> &#8358;</small> <?php echo e(number_format($item->price, '0', '.', ',')); ?></span>
                                    <a  class="deta animated fadeInRight"
                                        href="<?php echo e(route('getProductDetails', [
                                        'taxon_slug' => $item->taxons->first()->slug,
                                        'product_slug' => $item->slug
                            ])); ?>">
                            View Detail</a> </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <?php else: ?>
                            <div class="tab-pane animated fadeInDown" id="<?php echo e($category->taxonomy->name); ?>" role="tabpanel">

                            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->hasPhoto()): ?>
                                    <!-- Item -->
                                        <div class="item">
                                            <div class="img-ser">
                                                <img
                                                        class="img-1 lazyload"
                                                        src="<?php echo e($item->FirstImage); ?>"
                                                        alt="<?php echo e($item->title()); ?>"
                                                >
                                                <img class="img-2 lazyload" src="<?php echo e($item->FirstImage); ?>" alt="">

                                            </div>
                                            <!-- Item Name -->
                                            <div class="item-name">
                                                    <a  class="i-tittle"
                                                        href="<?php echo e(route('getProductDetails', [
                                                    'taxon_slug' => $item->taxons->first()->slug,
                                                    'product_slug' => $item->slug
                                                    ])); ?>">
                                                        <?php echo e(str_limit(strtoupper($item->title()),20, '...')); ?>

                                                    </a>
                                                <span class="price"><small> &#8358;</small> <?php echo e(number_format($item->price, '0', '.', ',')); ?></span>
                                                <a  class="deta animated fadeInRight"
                                                    href="<?php echo e(route('getProductDetails', [
                                                    'taxon_slug' => $item->taxons->first()->slug,
                                                    'product_slug' => $item->slug
                                                    ])); ?>">
                                                    View Detail</a> </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>