<div class="card">
    <div class="card-body">
        <h5 class="card-title mb-4">Properties</h5>
        <div class="table-responsive">
            <table class="table table-hover " id="categories-table">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Values</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($property->name); ?>

                        </td>
                        <td>
                            <div class="row">
                                <?php $__currentLoopData = $property->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 pb-1">
                                        <span><?php echo e($property_value->value); ?> </span>
                                        <a class="btn btn-xs btn-link delete_property_value" id="<?php echo e($property_value->id); ?>"><i class="fas fa-trash"></i></a>
                                        <a class="btn btn-xs btn-link edit_property_value" id="<?php echo e($property_value->id); ?>" data-property_id="<?php echo e($property_value->id); ?>"><i class="fas fa-edit"></i></a>
                                    </div>
                                <?php if($property_value->title != ""): ?>
                                    <div class="col-6 pb-1">
                                        <span><?php echo e($property_value->title); ?> </span>
                                        <a class="btn btn-xs btn-link edit_property_title" id="<?php echo e($property_value->id); ?>"><i class="fas fa-edit"></i></a>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <td>
                            <a class="btn btn-sm btn-link delete_property" id="<?php echo e($property->slug); ?>"><i class="fas fa-trash"></i></a>
                            <a class="btn btn-sm btn-link edit_property" id="<?php echo e($property->slug); ?>"><i class="fas fa-edit"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
