<?php $__env->startSection('content'); ?>

<!--======= SUB BANNER =========-->
<?php echo $__env->make('partials.frontend.sub_banner', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Content -->
<div id="content">

    <!-- Popular Products -->
    <section class="padding-top-100 padding-bottom-100">
        <div class="container">

            <!-- SHOP DETAIL -->
            <div class="shop-detail">
                <div class="row">
                <div class="col-md-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <div class="container">
                                <div class="alert-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="fa fa-close"></i></span>
                                </button>
                                <?php echo e(session('status')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <div class="container">
                                    <div class="alert-icon">
                                        <i class="fa fa-exclamation-circle"></i>
                                    </div>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                                    </button>
                                    <?php echo e(session('error')); ?>

                                </div>
                            </div>
                    <?php endif; ?>
                </div>
                    <!-- Popular Images Slider -->
                    <div class="col-md-7">
                        <!-- Place somewhere in the <body> of your page -->
                        <div id="slider-shop" class="flexslider">
                            <ul class="slides">
                                <?php if($product->photos): ?>
                                    <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li> <img class="img-responsive" src="<?php echo e(asset($image->ImageUrl)); ?>" alt="<?php echo e($product->title()); ?>"> </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div id="shop-thumb" class="flexslider">
                            <ul class="slides">
                                <?php if($product->photos): ?>
                                    <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li> <img class="img-responsive" src="<?php echo e(asset($image->ImageUrl)); ?>" alt="<?php echo e($product->title()); ?>"> </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- COntent -->
                    <div class="col-md-5">
                        <h4><?php echo e($product->title()); ?></h4>
                        <select class="product-rating-view">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?php if($i <= round($ratings) ): ?>
                                    <option value="1"></option>
                                <?php else: ?>
                                    <option value="2"></option>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </select>
                        <span class="price"><small>&#8358;</small> <?php echo e(number_format($product->price, '0', '.', ',')); ?></span>
                        <ul class="item-owner">
                            <li>Category:<span> <?php echo e($product->taxons->first()->slug); ?></span></li>
                            <li>Tags:
                                <?php if(isset($tags)): ?>
                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-primary text-white"><?php echo e($tag); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </li>
                        </ul>
                        <!-- Item Detail -->
                        <p><?php echo e($product->meta_description); ?></p>

                        <!-- Short By -->
                        <div class="some-info">
                            <ul class="row margin-top-30">
                                <li class="col-sm-6">
                                    <!-- Quantity -->
                                    <div class="quinty">
                                        <button type="button" class="quantity-left-minus"  data-type="minus" data-field=""> <span>-</span> </button>
                                        <input type="number" id="quantity" name="item_qty" class="form-control input-number" value="1">
                                        <button type="button" class="quantity-right-plus" data-type="plus" data-field=""> <span>+</span> </button>
                                    </div>
                                </li>

                                <!-- ADD TO CART -->
                                <li class="col-sm-6"> <a href="#." class="btn" data-slug="<?php echo e($product->slug); ?>" id="add_to_cart"> <i class="fa fa-circle-o-notch fa-spin processing off" aria-hidden="true"></i> ADD TO CART</a> </li>
                            </ul>

                            <!-- INFOMATION -->
                            <div class="inner-info">
                                <h5>Share this item with your friends</h5>
                                <!-- Social Icons -->
                                <ul class="social_icons">
                                    <li><a href="#."><i class="icon-social-facebook"></i></a></li>
                                    <li><a href="#."><i class="icon-social-twitter"></i></a></li>
                                    <li><a href="#."><i class="icon-social-tumblr"></i></a></li>
                                    <li><a href="#."><i class="icon-social-youtube"></i></a></li>
                                    <li><a href="#."><i class="icon-social-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--======= PRODUCT DESCRIPTION =========-->
            <div class="item-decribe">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
            <?php endif; ?>
                <!-- Nav tabs -->
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item"> <a class="active nav-link" href="#descr" role="tab" data-toggle="pill">DESCRIPTION</a></li>
                    <li class="nav-item"><a class="nav-link" href="#review" role="tab" data-toggle="pill">REVIEW (<?php echo e($product->commentCount()); ?>)</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <!-- DESCRIPTION -->
                    <div role="tabpanel" class="tab-pane active" id="descr">
                    <?php echo e($product->meta_description); ?>

                    </div>

                    <!-- REVIEW -->
                    <div role="tabpanel" class="tab-pane fade" id="review">
                        <?php if(isset($product->comments)): ?>
                            <?php if(count($product->comments)): ?>
                        <h6><?php echo e($product->commentCount()); ?> REVIEWS FOR SHIP YOUR <?php echo e(strtoupper($product->title())); ?></h6>
                                <?php else: ?>
                                <h6>Be the first to add a review</h6>
                            <?php endif; ?>
                        <?php endif; ?>
                            <?php if(count($product->comments)): ?>
                                <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- REVIEW PEOPLE 1 -->
                        <div class="media">
                            <div class="media-left">
                                <!--  Image -->
                                <div class="avatar"> <a href="#"> <img class="media-object" src="images/avatar-1.jpg" alt=""> </a> </div>
                            </div>
                            <!--  Details -->
                            <div class="media-body">
                                <p><?php echo e($comment->body); ?></p>
                                <h6> <?php echo e(strtoupper($comment->creator->firstname)); ?> <span class="pull-right"><?php echo e($comment->created_at->diffForHumans()); ?></span> </h6>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                        <!-- ADD REVIEW -->
                        <h6 class="margin-t-40">ADD YOUR REVIEW</h6>
                        <form action="<?php echo e(route('add_comment', ['product_id' => $product->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <ul class="row">
                                <li class="col-sm-6">
                                    <label> *NAME
                                        <?php if(Auth::guest()): ?>
                                            <input type="text" value="" name="name" placeholder="Guest" disabled>
                                        <?php else: ?>
                                            <input type="text" value="" placeholder="<?php echo e(Auth::user()->firstname); ?>" disabled>
                                        <?php endif; ?>
                                    </label>
                                </li>
                                <li class="col-sm-6">
                                    <label> *Subject
                                            <input type="text" value="" name="title">
                                    </label>
                                </li>
                                <li class="col-sm-12">
                                    <label> *YOUR REVIEW
                                        <textarea name="comment"></textarea>
                                    </label>
                                </li>
                                <li class="col-sm-6">
                                    <!-- Rating Stars -->
                                    <span class="rating_indicator off">
                                            <i class="fa fa-circle-o-notch fa-spin processing" aria-hidden="true"></i>
                                            <span> Rating...</span>
                                        </span>
                                    <select class="product-rating-comment" data-slug="<?php echo e($product->slug); ?>">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                    
                                </li>
                                <li class="col-sm-6">
                                    <button type="submit" class="btn btn-dark btn-small pull-right no-margin">POST REVIEW</button>
                                </li>
                            </ul>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>

        $(document).ready(function () {

            $("#add_to_cart").click(function () {
                $(".processing").removeClass('off')
                $("#add_to_cart").prop('disabled', true)
                var slug = $(this).data('slug');
                var qty = $("input[name='item_qty']").val();
                if(qty < 1){
                    alert('Qty less than 1')
                    return false;
                }
                $.ajax({
                    url: "<?php echo e(route('add_to_cart')); ?>",
                    type: 'POST',
                    data: {qty: qty, slug:slug}
                })
                    .done(function (data) {
                        $(".processing").addClass('off')
                        $("#add_to_cart").prop('disabled', false)
                        $(".cart_count").html("<i>"+data.cart_count+"</i>")
                        Snackbar.show({
                            showAction: true,
                            text: 'Cart updated.',
                            actionTextColor: '#ffffff',
                            backgroundColor:"#53A6E8"
                        });

                    }).fail(function (error) {
                    $(".processing").addClass('off')
                    $("#add_to_cart").prop('disabled', false)
                    Snackbar.show({
                        showAction: true,
                        text: 'Cart update failed!.',
                        actionTextColor: '#ffffff',
                        backgroundColor:"#FE970D"
                    });
                });
            });

            $('select.product-rating-comment').barrating({
                theme: 'fontawesome-stars',
                onSelect: function(value, text, event) {
                    if (typeof(event) !== 'undefined') {
                        // rating was selected by a user
                        $(".rating_indicator").removeClass('off')
                        var rating = $(event.target).data('rating-value');
                        var slug = $(event.target).parent().prev().data('slug');

                        $.ajax({
                            url: "<?php echo e(route('rate_product')); ?>",
                            type: 'POST',
                            data: {rating: rating, slug: slug}
                        })
                            .done(function (data) {
                                $(".rating_indicator").addClass('off')
                                Snackbar.show({
                                    showAction: true,
                                    text: 'Product rated.',
                                    actionTextColor: '#ffffff',
                                    backgroundColor: "#53A6E8"
                                });

                            }).fail(function (error) {
                            $(".rating_indicator").addClass('off')
                            Snackbar.show({
                                showAction: true,
                                text: 'Product rating failed!.',
                                actionTextColor: '#ffffff',
                                backgroundColor: "#FE970D"
                            });
                        })
                    }else {
                        // rating was selected programmatically
                        // by calling `set` method
                    }
                }
            });
            $('select.product-rating-view').barrating({
                theme: 'fontawesome-stars',
                readonly: true
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.newmain', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>