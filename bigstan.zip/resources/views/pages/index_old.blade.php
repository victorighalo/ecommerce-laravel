@extends('layouts.main')

@section('content')
@include('partials.slider')
@include('partials.categories')
@include('partials.new_products')
@include('partials.products_by_category')
{{--@include('partials.featured_products')--}}
@include('partials.features')
    @endsection