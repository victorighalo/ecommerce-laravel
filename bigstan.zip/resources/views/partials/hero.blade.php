<div class="ps-hero bg--cover" data-background="{{asset('images/hero/bread-1.jpg')}}">
    <div class="ps-container">
        <h3>{{$page}}</h3>
        <div class="ps-breadcrumb">
            <ol class="breadcrumb">
                <li><a href="{{url('/')}}">Home</a></li>
                <li class="active">{{$page}}</li>
            </ol>
        </div>
    </div>
</div>
