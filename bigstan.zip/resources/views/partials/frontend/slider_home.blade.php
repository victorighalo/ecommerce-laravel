<section class="home-slide simple-head" data-stellar-background-ratio="0.5">
    <div class="container">
        <!-- Item Slider -->
        <div class="single-slide">

            <!-- Slider Content -->
            <div class="owl-slide">
                <!-- Header Text -->
                <div class="text-left col-md-11 no-padding"> <span class="price"><small>$</small>299.99</span>
                    <h4>The Latest Winter Product for 2018</h4>
                    <h1 class="extra-huge-text">look hot with 2018 style</h1>
                    <div class="text-btn"> <a href="#." class="btn btn-inverse margin-top-40">SHOP NOW</a> </div>
                </div>
            </div>

            <!-- Slider Content -->
            <div class="owl-slide">
                <!-- Header Text -->
                <div class="text-left col-md-11 no-padding"> <span class="price"><small>$</small>299.99</span>
                    <h4>The Huge Summer Shop for 2018</h4>
                    <h1 class="extra-huge-text">Perfect 2018 Fashion Style</h1>
                    <div class="text-btn"> <a href="#." class="btn btn-inverse margin-top-40">SHOP NOW</a> </div>
                </div>
            </div>

            <!-- Slider Content -->
            <div class="owl-slide">
                <!-- Header Text -->
                <div class="text-left col-md-11 no-padding"> <span class="price"><small>$</small>299.99</span>
                    <h4>Summer/Winter for 2018</h4>
                    <h1 class="extra-huge-text">All of the Best Collections </h1>
                    <div class="text-btn"> <a href="#." class="btn btn-inverse margin-top-40">SHOP NOW</a> </div>
                </div>
            </div>
        </div>
    </div>
</section>
