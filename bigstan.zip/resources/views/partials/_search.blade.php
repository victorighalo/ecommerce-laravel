<form class="ps-form--search" action="{{url('search')}}" method="get"><i class="furniture-search"></i>
    <input class="form-control" type="text" placeholder="Find product" name="product">
    <button>Search</button>
</form>