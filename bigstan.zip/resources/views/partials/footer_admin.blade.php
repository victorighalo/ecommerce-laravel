<footer class="footer">
    <div class="container-fluid clearfix">
        <span class="text-muted d-block text-center text-sm-left d-sm-inline-block"> <a href="#" target="_blank">E-Commerce Laravel</a>. Designed by <a href="https://twitter.com/victorighalo">WyzWeb</a> .</span>
    </div>
</footer>