
<div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true" id="images-modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Images</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <h4 class="image_load_status text-center invalid-feedback "></h4>
                <form action="" method="" name="add_images_form">

                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="add_images">Save changes</button>
            </div>
        </div>
    </div>
</div>
