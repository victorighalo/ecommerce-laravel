<?php

return [

    /*
     * The models for rating tables.
     */

    'models' => [
        'rating' => \Rennokki\Rating\Models\RaterModel::class,
    ],

];
