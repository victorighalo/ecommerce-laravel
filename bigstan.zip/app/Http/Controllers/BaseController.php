<?php


namespace App\Http\Controllers;


use Illuminate\Support\Facades\View;
use Vanilo\Cart\Facades\Cart;

class BaseController extends Controller
{
    public function __construct()
    {

    }
}