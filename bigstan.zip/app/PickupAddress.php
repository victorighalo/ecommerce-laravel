<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PickupAddress extends Model
{
    //
}
